import { create } from 'zustand';
import { ColorScheme } from '@/constants/Colors';
import { useColorScheme } from 'react-native';

interface ThemeState {
  theme: ColorScheme;
  systemTheme: ColorScheme;
  useSystemTheme: boolean;
  
  // Actions
  setTheme: (theme: ColorScheme) => void;
  setUseSystemTheme: (useSystem: boolean) => void;
  toggleTheme: () => void;
  
  // Computed
  currentTheme: () => ColorScheme;
}

const useThemeStore = create<ThemeState>((set, get) => ({
  theme: 'light',
  systemTheme: 'light',
  useSystemTheme: true,
  
  setTheme: (theme) => set({ theme }),
  
  setUseSystemTheme: (useSystemTheme) => set({ useSystemTheme }),
  
  toggleTheme: () => set((state) => ({ 
    theme: state.theme === 'light' ? 'dark' : 'light' 
  })),
  
  currentTheme: () => {
    const state = get();
    return state.useSystemTheme ? state.systemTheme : state.theme;
  },
}));

// Update system theme when it changes
export const useSystemThemeWatcher = () => {
  const colorScheme = useColorScheme() as ColorScheme || 'light';
  const { setTheme, useSystemTheme } = useThemeStore();
  
  // Update the system theme in our store
  useThemeStore.setState({ systemTheme: colorScheme });
  
  // If we're using system theme, also update the active theme
  if (useSystemTheme) {
    setTheme(colorScheme);
  }
  
  return colorScheme;
};

export default useThemeStore;