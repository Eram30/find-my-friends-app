import { create } from 'zustand';
import { Friend, FriendRequest } from '@/types';

interface FriendsState {
  friends: Friend[];
  friendRequests: FriendRequest[];
  isLoading: boolean;
  error: string | null;
  
  // Actions
  setFriends: (friends: Friend[]) => void;
  setFriendRequests: (requests: FriendRequest[]) => void;
  addFriend: (friend: Friend) => void;
  removeFriend: (friendId: string) => void;
  updateFriendLocation: (friendId: string, location: Friend['location']) => void;
  toggleFriendFavorite: (friendId: string) => void;
  toggleFriendSharing: (friendId: string, isSharing: boolean) => void;
  addFriendRequest: (request: FriendRequest) => void;
  removeFriendRequest: (requestId: string) => void;
  updateFriendRequest: (requestId: string, status: FriendRequest['status']) => void;
  setLoading: (isLoading: boolean) => void;
  setError: (error: string | null) => void;
}

const useFriendsStore = create<FriendsState>((set, get) => ({
  friends: [],
  friendRequests: [],
  isLoading: false,
  error: null,
  
  setFriends: (friends) => set({ friends }),
  setFriendRequests: (friendRequests) => set({ friendRequests }),
  
  addFriend: (friend) => set((state) => ({ 
    friends: [...state.friends, friend] 
  })),
  
  removeFriend: (friendId) => set((state) => ({ 
    friends: state.friends.filter(f => f.id !== friendId) 
  })),
  
  updateFriendLocation: (friendId, location) => set((state) => ({
    friends: state.friends.map(friend => 
      friend.id === friendId 
      ? { 
          ...friend, 
          location, 
          lastLocationUpdate: location ? new Date() : friend.lastLocationUpdate 
        } 
      : friend
    )
  })),
  
  toggleFriendFavorite: (friendId) => set((state) => ({
    friends: state.friends.map(friend => 
      friend.id === friendId 
      ? { ...friend, isFavorite: !friend.isFavorite } 
      : friend
    )
  })),
  
  toggleFriendSharing: (friendId, isSharing) => set((state) => ({
    friends: state.friends.map(friend => 
      friend.id === friendId 
      ? { ...friend, isSharing } 
      : friend
    )
  })),
  
  addFriendRequest: (request) => set((state) => ({ 
    friendRequests: [...state.friendRequests, request] 
  })),
  
  removeFriendRequest: (requestId) => set((state) => ({ 
    friendRequests: state.friendRequests.filter(r => r.id !== requestId) 
  })),
  
  updateFriendRequest: (requestId, status) => set((state) => ({
    friendRequests: state.friendRequests.map(request => 
      request.id === requestId 
      ? { ...request, status } 
      : request
    )
  })),
  
  setLoading: (isLoading) => set({ isLoading }),
  setError: (error) => set({ error }),
}));

export default useFriendsStore;