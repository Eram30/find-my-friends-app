import { create } from 'zustand';
import { Geofence } from '@/types';

interface GeofenceState {
  geofences: Geofence[];
  activeGeofences: string[];
  isLoading: boolean;
  error: string | null;
  
  // Actions
  setGeofences: (geofences: Geofence[]) => void;
  addGeofence: (geofence: Geofence) => void;
  updateGeofence: (geofenceId: string, updates: Partial<Geofence>) => void;
  removeGeofence: (geofenceId: string) => void;
  setActiveGeofences: (geofenceIds: string[]) => void;
  addActiveGeofence: (geofenceId: string) => void;
  removeActiveGeofence: (geofenceId: string) => void;
  setLoading: (isLoading: boolean) => void;
  setError: (error: string | null) => void;
}

const useGeofenceStore = create<GeofenceState>((set) => ({
  geofences: [],
  activeGeofences: [],
  isLoading: false,
  error: null,
  
  setGeofences: (geofences) => set({ geofences }),
  
  addGeofence: (geofence) => set((state) => ({ 
    geofences: [...state.geofences, geofence] 
  })),
  
  updateGeofence: (geofenceId, updates) => set((state) => ({
    geofences: state.geofences.map(geofence => 
      geofence.id === geofenceId 
      ? { ...geofence, ...updates } 
      : geofence
    )
  })),
  
  removeGeofence: (geofenceId) => set((state) => ({ 
    geofences: state.geofences.filter(g => g.id !== geofenceId),
    activeGeofences: state.activeGeofences.filter(id => id !== geofenceId)
  })),
  
  setActiveGeofences: (geofenceIds) => set({ activeGeofences: geofenceIds }),
  
  addActiveGeofence: (geofenceId) => set((state) => ({ 
    activeGeofences: [...state.activeGeofences, geofenceId] 
  })),
  
  removeActiveGeofence: (geofenceId) => set((state) => ({ 
    activeGeofences: state.activeGeofences.filter(id => id !== geofenceId) 
  })),
  
  setLoading: (isLoading) => set({ isLoading }),
  setError: (error) => set({ error }),
}));

export default useGeofenceStore;

export { useGeofenceStore }