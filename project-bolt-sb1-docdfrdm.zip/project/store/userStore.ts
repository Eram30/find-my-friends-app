import { create } from 'zustand';
import { User, Location } from '@/types';

interface UserState {
  user: User | null;
  location: Location | null;
  isLocationSharing: boolean;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  setUser: (user: User | null) => void;
  setLocation: (location: Location | null) => void;
  setLocationSharing: (isSharing: boolean) => void;
  setLoading: (isLoading: boolean) => void;
  setError: (error: string | null) => void;
  logout: () => void;
}

const useUserStore = create<UserState>((set) => ({
  user: null,
  location: null,
  isLocationSharing: false,
  isLoading: false,
  error: null,
  
  setUser: (user) => set({ user }),
  setLocation: (location) => set({ location }),
  setLocationSharing: (isLocationSharing) => set({ isLocationSharing }),
  setLoading: (isLoading) => set({ isLoading }),
  setError: (error) => set({ error }),
  logout: () => set({ 
    user: null, 
    location: null, 
    isLocationSharing: false, 
    error: null 
  }),
}));

export default useUserStore;