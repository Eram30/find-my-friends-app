import { useEffect } from 'react';
import useFriendsStore from '@/store/friendsStore';
import { Friend, Location } from '@/types';
import { mockFriends } from '@/utils/mockData';

// For demo purposes, we're simulating location updates
// In a real app, this would connect to a backend service
export default function useFriendLocation() {
  const {
    friends,
    setFriends,
    updateFriendLocation,
  } = useFriendsStore();
  
  // Initialize with mock data if empty
  useEffect(() => {
    if (friends.length === 0) {
      setFriends(mockFriends);
    }
  }, []);
  
  // Function to simulate random location updates
  useEffect(() => {
    // Only update friends who are sharing their location
    const sharingFriends = friends.filter(f => f.isSharing);
    
    if (sharingFriends.length === 0) return;
    
    const intervalId = setInterval(() => {
      // Choose a random friend
      const randomIndex = Math.floor(Math.random() * sharingFriends.length);
      const friend = sharingFriends[randomIndex];
      
      if (friend && friend.location) {
        // Update with a slightly changed location (random drift)
        const latDrift = (Math.random() - 0.5) * 0.0005; // Small random change
        const lngDrift = (Math.random() - 0.5) * 0.0005; // Small random change
        
        const newLocation: Location = {
          ...friend.location,
          latitude: friend.location.latitude + latDrift,
          longitude: friend.location.longitude + lngDrift,
          timestamp: Date.now(),
        };
        
        updateFriendLocation(friend.id, newLocation);
      }
    }, 5000); // Update every 5 seconds
    
    return () => clearInterval(intervalId);
  }, [friends]);
  
  // Get friends who are sharing location
  const getSharingFriends = (): Friend[] => {
    return friends.filter(f => f.isSharing && f.location);
  };
  
  return {
    allFriends: friends,
    sharingFriends: getSharingFriends(),
    updateFriendLocation,
  };
}