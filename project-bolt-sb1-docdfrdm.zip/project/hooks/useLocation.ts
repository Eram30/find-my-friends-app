import { useState, useEffect } from 'react';
import * as Location from 'expo-location';
import { Platform } from 'react-native';
import { Location as LocationType } from '@/types';
import useUserStore from '@/store/userStore';

// Default location (NYC)
const DEFAULT_LOCATION = {
  latitude: 40.7128,
  longitude: -74.0060,
  accuracy: 50,
  timestamp: Date.now(),
};

export default function useLocation() {
  const [location, setLocation] = useState<LocationType | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  
  const storeLocation = useUserStore(state => state.setLocation);
  const isLocationSharing = useUserStore(state => state.isLocationSharing);
  
  useEffect(() => {
    let locationSubscription: Location.LocationSubscription | null = null;
    
    (async () => {
      setIsLoading(true);
      
      try {
        let { status } = await Location.requestForegroundPermissionsAsync();
        
        if (status !== 'granted') {
          setErrorMsg('Permission to access location was denied');
          
          // On web, we'll use a default location if permission is denied
          if (Platform.OS === 'web') {
            setLocation(DEFAULT_LOCATION);
            storeLocation(DEFAULT_LOCATION);
          }
          
          setIsLoading(false);
          return;
        }
        
        // Get initial location
        const initialLocation = await Location.getCurrentPositionAsync({});
        const locationData = {
          latitude: initialLocation.coords.latitude,
          longitude: initialLocation.coords.longitude,
          accuracy: initialLocation.coords.accuracy,
          altitude: initialLocation.coords.altitude,
          heading: initialLocation.coords.heading,
          speed: initialLocation.coords.speed,
          timestamp: initialLocation.timestamp,
        };
        
        setLocation(locationData);
        storeLocation(locationData);
        
        // Subscribe to location updates if sharing is enabled
        if (isLocationSharing) {
          locationSubscription = await Location.watchPositionAsync(
            {
              accuracy: Location.Accuracy.Balanced,
              distanceInterval: 10, // meters
              timeInterval: 10000, // 10 seconds
            },
            (newLocation) => {
              const updatedLocation = {
                latitude: newLocation.coords.latitude,
                longitude: newLocation.coords.longitude,
                accuracy: newLocation.coords.accuracy,
                altitude: newLocation.coords.altitude,
                heading: newLocation.coords.heading,
                speed: newLocation.coords.speed,
                timestamp: newLocation.timestamp,
              };
              
              setLocation(updatedLocation);
              storeLocation(updatedLocation);
            }
          );
        }
      } catch (error) {
        setErrorMsg('Could not get location: ' + (error as Error).message);
        
        // Use default location on error for web
        if (Platform.OS === 'web') {
          setLocation(DEFAULT_LOCATION);
          storeLocation(DEFAULT_LOCATION);
        }
      } finally {
        setIsLoading(false);
      }
    })();
    
    return () => {
      if (locationSubscription) {
        locationSubscription.remove();
      }
    };
  }, [isLocationSharing]);
  
  return {
    location,
    errorMsg,
    isLoading,
  };
}