import React, { useState } from 'react';
import { StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { View, Text, Card } from '@/components/themed';
import useThemeStore from '@/store/themeStore';
import Colors from '@/constants/Colors';
import spacing from '@/constants/Spacing';
import { Bell, BellOff, Check, MapPin, User, Heart } from 'lucide-react-native';
import { useGeofenceStore } from '@/store/geofenceStore';
import useFriendsStore from '@/store/friendsStore';
import { Friend } from '@/types';

// Mock notifications data
const mockNotifications = [
  {
    id: 'notif-1',
    type: 'geofence' as const,
    title: 'Emma Johnson arrived at Home',
    message: 'She entered the geofence area 5 minutes ago',
    read: false,
    timestamp: new Date(Date.now() - 5 * 60 * 1000), // 5 mins ago
    data: {
      friendId: 'friend-1',
      geofenceId: 'geofence-1',
      action: 'enter' as const,
    },
  },
  {
    id: 'notif-2',
    type: 'locationSharing' as const,
    title: 'James Smith started sharing location',
    message: 'You can now see their location on the map',
    read: true,
    timestamp: new Date(Date.now() - 30 * 60 * 1000), // 30 mins ago
    data: {
      friendId: 'friend-2',
    },
  },
  {
    id: 'notif-3',
    type: 'geofence' as const,
    title: 'Sophia Williams left Work',
    message: 'She left the geofence area 45 minutes ago',
    read: true,
    timestamp: new Date(Date.now() - 45 * 60 * 1000), // 45 mins ago
    data: {
      friendId: 'friend-3',
      geofenceId: 'geofence-2',
      action: 'exit' as const,
    },
  },
  {
    id: 'notif-4',
    type: 'friendRequest' as const,
    title: 'Friend request accepted',
    message: 'Michael Brown accepted your friend request',
    read: false,
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
    data: {
      friendId: 'friend-4',
    },
  },
  {
    id: 'notif-5',
    type: 'system' as const,
    title: 'Find My Friends updated',
    message: 'New features and improvements are available in this update',
    read: true,
    timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
    data: {},
  },
];

export default function NotificationsScreen() {
  const theme = useThemeStore(state => state.currentTheme());
  const colors = Colors[theme];
  
  // Stores
  const geofenceStore = useGeofenceStore();
  const { geofences } = geofenceStore;
  
  const friendsStore = useFriendsStore();
  const { friends } = friendsStore;
  
  // State
  const [notifications, setNotifications] = useState(mockNotifications);
  const [filter, setFilter] = useState<'all' | 'unread'>('all');
  
  // Filter notifications
  const filteredNotifications = filter === 'all' 
    ? notifications 
    : notifications.filter(n => !n.read);
  
  // Mark notification as read
  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
  };
  
  // Format notification time
  const formatTime = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffDays > 0) {
      return `${diffDays}d ago`;
    } else if (diffHours > 0) {
      return `${diffHours}h ago`;
    } else {
      return `${diffMins}m ago`;
    }
  };
  
  // Get icon for notification type
  const getNotificationIcon = (type: string, action?: string) => {
    switch (type) {
      case 'geofence':
        return <MapPin size={20} color={action === 'enter' ? colors.success[500] : colors.warning[500]} />;
      case 'locationSharing':
        return <Heart size={20} color={colors.primary[500]} />;
      case 'friendRequest':
        return <User size={20} color={colors.primary[500]} />;
      case 'system':
        return <Bell size={20} color={colors.secondary[500]} />;
      default:
        return <Bell size={20} color={colors.primary[500]} />;
    }
  };
  
  // Get friend data
  const getFriend = (friendId: string): Friend | undefined => {
    return friends.find(f => f.id === friendId);
  };
  
  // Get geofence name
  const getGeofenceName = (geofenceId: string): string => {
    const geofence = geofences.find(g => g.id === geofenceId);
    return geofence?.name || 'Unknown location';
  };
  
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text variant="heading3">Notifications</Text>
        
        {/* Filter toggle */}
        <View style={styles.filterContainer}>
          <TouchableOpacity
            style={[
              styles.filterButton,
              filter === 'all' && { backgroundColor: colors.primary[500] }
            ]}
            onPress={() => setFilter('all')}
          >
            <Bell 
              size={18} 
              color={filter === 'all' ? colors.text.inverse : colors.text.primary} 
            />
            <Text 
              variant="caption"
              color={filter === 'all' ? colors.text.inverse : colors.text.primary}
            >
              All
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.filterButton,
              filter === 'unread' && { backgroundColor: colors.primary[500] }
            ]}
            onPress={() => setFilter('unread')}
          >
            <BellOff 
              size={18} 
              color={filter === 'unread' ? colors.text.inverse : colors.text.primary} 
            />
            <Text 
              variant="caption"
              color={filter === 'unread' ? colors.text.inverse : colors.text.primary}
            >
              Unread
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <ScrollView 
        style={styles.content} 
        contentContainerStyle={styles.contentContainer}
        showsVerticalScrollIndicator={false}
      >
        {filteredNotifications.length > 0 ? (
          filteredNotifications.map(notification => (
            <TouchableOpacity
              key={notification.id}
              onPress={() => markAsRead(notification.id)}
              activeOpacity={0.7}
            >
              <Card 
                style={[
                  styles.notificationCard,
                  !notification.read && { 
                    borderLeftWidth: 3,
                    borderLeftColor: colors.primary[500],
                  }
                ]}
              >
                <View style={styles.notificationHeader}>
                  <View style={styles.iconContainer}>
                    {getNotificationIcon(
                      notification.type, 
                      notification.type === 'geofence' ? notification.data.action : undefined
                    )}
                  </View>
                  
                  <View style={styles.notificationMeta}>
                    <Text variant="subtitle" numberOfLines={1}>{notification.title}</Text>
                    <Text variant="caption" color={colors.text.secondary}>
                      {formatTime(notification.timestamp)}
                    </Text>
                  </View>
                  
                  {!notification.read && (
                    <TouchableOpacity 
                      style={styles.markButton}
                      onPress={() => markAsRead(notification.id)}
                    >
                      <Check size={16} color={colors.primary[500]} />
                    </TouchableOpacity>
                  )}
                </View>
                
                <Text 
                  variant="bodySmall" 
                  color={colors.text.secondary}
                  style={styles.notificationMessage}
                >
                  {notification.message}
                </Text>
              </Card>
            </TouchableOpacity>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Bell size={48} color={colors.text.tertiary} />
            <Text 
              variant="subtitle" 
              color={colors.text.secondary}
              style={styles.emptyText}
            >
              No {filter === 'unread' ? 'unread ' : ''}notifications
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 60,
  },
  header: {
    paddingHorizontal: spacing['4'],
    paddingBottom: spacing['4'],
  },
  filterContainer: {
    flexDirection: 'row',
    marginTop: spacing['3'],
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing['3'],
    paddingVertical: spacing['1.5'],
    borderRadius: spacing['7'],
    marginRight: spacing['2'],
    gap: spacing['1'],
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: spacing['4'],
    paddingTop: spacing['2'],
    paddingBottom: spacing['6'],
  },
  notificationCard: {
    marginBottom: spacing['3'],
  },
  notificationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.03)',
  },
  notificationMeta: {
    flex: 1,
    marginLeft: spacing['2'],
  },
  markButton: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  notificationMessage: {
    marginTop: spacing['2'],
    marginLeft: spacing['7'],
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing['10'],
  },
  emptyText: {
    marginTop: spacing['3'],
  },
});