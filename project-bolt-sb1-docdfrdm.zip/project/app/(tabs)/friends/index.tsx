import React, { useState } from 'react';
import { StyleSheet, FlatList, TouchableOpacity, ScrollView } from 'react-native';
import { View, Text, Card, Button, Avatar } from '@/components/themed';
import { FriendCard } from '@/components/themed';
import useThemeStore from '@/store/themeStore';
import Colors from '@/constants/Colors';
import spacing from '@/constants/Spacing';
import { Search, UserPlus, UserMinus, Check, X, Share2 } from 'lucide-react-native';
import useFriendsStore from '@/store/friendsStore';
import { mockFriendRequests, mockUsers } from '@/utils/mockData';
import { FriendRequest, User } from '@/types';

export default function FriendsScreen() {
  const theme = useThemeStore(state => state.currentTheme());
  const colors = Colors[theme];
  
  // State
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'favorites' | 'requests'>('all');
  
  // Get friends data
  const {
    friends,
    friendRequests,
    setFriendRequests,
    toggleFriendFavorite,
    toggleFriendSharing,
  } = useFriendsStore();
  
  // Initialize with mock data if empty
  React.useEffect(() => {
    if (friendRequests.length === 0) {
      setFriendRequests(mockFriendRequests);
    }
  }, []);
  
  // Filter friends based on active tab and search query
  const getFilteredFriends = () => {
    let filtered = friends;
    
    // Filter by tab
    if (activeTab === 'favorites') {
      filtered = filtered.filter(friend => friend.isFavorite);
    }
    
    // Filter by search query if exists
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(friend => 
        friend.name.toLowerCase().includes(query)
      );
    }
    
    return filtered;
  };
  
  // Get incoming friend requests
  const incomingRequests = friendRequests.filter(
    request => request.receiverId === 'current-user' && request.status === 'pending'
  );
  
  // Get outgoing friend requests
  const outgoingRequests = friendRequests.filter(
    request => request.senderId === 'current-user' && request.status === 'pending'
  );
  
  // Filtered friends based on current filters
  const filteredFriends = getFilteredFriends();
  
  // Render friend request card
  const renderRequestCard = ({ item }: { item: FriendRequest }) => {
    // Find the user details for this request
    const isIncoming = item.receiverId === 'current-user';
    const userId = isIncoming ? item.senderId : item.receiverId;
    
    // Mock user data for demo - in real app would come from API
    const userDetail = mockUsers.find(u => u.id === userId) || {
      id: userId,
      name: isIncoming ? 'Someone' : 'A Friend',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
      status: 'offline' as const,
    };
    
    return (
      <Card style={styles.requestCard}>
        <View style={styles.requestCardContent}>
          <Avatar source={{ uri: userDetail.avatar }} size="sm" status={userDetail.status} />
          
          <View style={styles.requestInfo}>
            <Text variant="subtitle" numberOfLines={1}>{userDetail.name}</Text>
            <Text variant="caption" color={colors.text.secondary}>
              {isIncoming ? 'Wants to connect with you' : 'Request sent'}
            </Text>
          </View>
          
          {isIncoming ? (
            <View style={styles.requestActions}>
              <TouchableOpacity style={styles.actionButton}>
                <X size={20} color={colors.error[500]} />
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionButton}>
                <Check size={20} color={colors.success[500]} />
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity style={styles.cancelButton}>
              <Text variant="caption" color={colors.error[500]}>Cancel</Text>
            </TouchableOpacity>
          )}
        </View>
      </Card>
    );
  };
  
  // Render friend suggestion card
  const renderSuggestionCard = ({ item }: { item: User }) => {
    return (
      <Card variant="outlined" style={styles.suggestionCard}>
        <View style={styles.suggestionContent}>
          <Avatar source={{ uri: item.avatar }} size="md" status={item.status} />
          <Text variant="bodySmall" style={styles.suggestionName}>{item.name}</Text>
          <Button
            size="sm"
            label="Add"
            icon={<UserPlus size={16} color={colors.text.inverse} />}
            style={styles.addButton}
          />
        </View>
      </Card>
    );
  };
  
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text variant="heading3">Friends</Text>
        
        {/* Search bar */}
        <View style={[styles.searchBar, { backgroundColor: colors.background.input }]}>
          <Search size={20} color={colors.text.secondary} />
          <Text variant="body" color={colors.text.tertiary} style={styles.searchPlaceholder}>
            Search friends...
          </Text>
        </View>
      </View>
      
      {/* Tab switcher */}
      <View style={styles.tabs}>
        <TouchableOpacity 
          style={[
            styles.tab, 
            activeTab === 'all' && { borderBottomColor: colors.primary[500] }
          ]} 
          onPress={() => setActiveTab('all')}
        >
          <Text 
            variant="bodySmall"
            color={activeTab === 'all' ? colors.primary[500] : colors.text.secondary}
          >
            All Friends
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[
            styles.tab, 
            activeTab === 'favorites' && { borderBottomColor: colors.primary[500] }
          ]} 
          onPress={() => setActiveTab('favorites')}
        >
          <Text 
            variant="bodySmall"
            color={activeTab === 'favorites' ? colors.primary[500] : colors.text.secondary}
          >
            Favorites
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[
            styles.tab, 
            activeTab === 'requests' && { borderBottomColor: colors.primary[500] }
          ]} 
          onPress={() => setActiveTab('requests')}
        >
          <View style={styles.tabWithBadge}>
            <Text 
              variant="bodySmall"
              color={activeTab === 'requests' ? colors.primary[500] : colors.text.secondary}
            >
              Requests
            </Text>
            
            {incomingRequests.length > 0 && (
              <View style={[styles.badge, { backgroundColor: colors.error[500] }]}>
                <Text variant="caption" color={colors.text.inverse} style={styles.badgeText}>
                  {incomingRequests.length}
                </Text>
              </View>
            )}
          </View>
        </TouchableOpacity>
      </View>
      
      {/* Main content based on active tab */}
      {activeTab !== 'requests' ? (
        <>
          {/* Friends list */}
          <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
            {filteredFriends.length > 0 ? (
              filteredFriends.map(friend => (
                <FriendCard
                  key={friend.id}
                  friend={friend}
                  onFavoritePress={() => toggleFriendFavorite(friend.id)}
                  onSharePress={() => toggleFriendSharing(friend.id, !friend.isSharing)}
                />
              ))
            ) : (
              <View style={styles.emptyState}>
                <Text color={colors.text.secondary}>
                  {activeTab === 'all' 
                    ? 'You have no friends yet' 
                    : 'No favorite friends'}
                </Text>
                
                {activeTab === 'all' && (
                  <Button
                    variant="primary"
                    label="Add Friends"
                    icon={<UserPlus size={20} color={colors.text.inverse} />}
                    style={styles.emptyButton}
                  />
                )}
              </View>
            )}
            
            {/* Friend suggestions */}
            {activeTab === 'all' && (
              <View style={styles.suggestionsSection}>
                <Text variant="subtitle" style={styles.sectionTitle}>
                  People you may know
                </Text>
                
                <FlatList
                  data={mockUsers}
                  renderItem={renderSuggestionCard}
                  keyExtractor={item => item.id}
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.suggestionsContainer}
                />
              </View>
            )}
          </ScrollView>
          
          {/* Add friend floating button */}
          <TouchableOpacity 
            style={[
              styles.floatingButton,
              { backgroundColor: colors.primary[500] }
            ]}
          >
            <UserPlus size={24} color={colors.text.inverse} />
          </TouchableOpacity>
        </>
      ) : (
        /* Requests tab content */
        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {/* Incoming requests */}
          {incomingRequests.length > 0 && (
            <View style={styles.requestsSection}>
              <Text variant="subtitle" style={styles.sectionTitle}>
                Friend Requests
              </Text>
              
              {incomingRequests.map(request => (
                <View key={request.id}>
                  {renderRequestCard({ item: request })}
                </View>
              ))}
            </View>
          )}
          
          {/* Outgoing requests */}
          {outgoingRequests.length > 0 && (
            <View style={styles.requestsSection}>
              <Text variant="subtitle" style={styles.sectionTitle}>
                Sent Requests
              </Text>
              
              {outgoingRequests.map(request => (
                <View key={request.id}>
                  {renderRequestCard({ item: request })}
                </View>
              ))}
            </View>
          )}
          
          {/* Empty state if no requests */}
          {incomingRequests.length === 0 && outgoingRequests.length === 0 && (
            <View style={styles.emptyState}>
              <Text color={colors.text.secondary}>
                No pending friend requests
              </Text>
              
              <Button
                variant="primary"
                label="Find Friends"
                icon={<UserPlus size={20} color={colors.text.inverse} />}
                style={styles.emptyButton}
              />
            </View>
          )}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 60,
  },
  header: {
    paddingHorizontal: spacing['4'],
    paddingBottom: spacing['4'],
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing['3'],
    paddingHorizontal: spacing['3'],
    paddingVertical: spacing['2'],
    borderRadius: spacing['1.5'],
  },
  searchPlaceholder: {
    marginLeft: spacing['2'],
    flex: 1,
  },
  tabs: {
    flexDirection: 'row',
    paddingHorizontal: spacing['4'],
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.05)',
  },
  tab: {
    paddingVertical: spacing['2'],
    marginRight: spacing['4'],
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  tabWithBadge: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  badge: {
    marginLeft: spacing['1'],
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    fontSize: 10,
    fontWeight: '600',
  },
  content: {
    flex: 1,
    paddingHorizontal: spacing['4'],
    paddingTop: spacing['3'],
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing['10'],
  },
  emptyButton: {
    marginTop: spacing['3'],
  },
  floatingButton: {
    position: 'absolute',
    right: spacing['4'],
    bottom: spacing['4'],
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
    elevation: 5,
  },
  suggestionsSection: {
    marginVertical: spacing['4'],
  },
  sectionTitle: {
    marginBottom: spacing['3'],
  },
  suggestionsContainer: {
    paddingRight: spacing['4'],
  },
  suggestionCard: {
    width: 120,
    marginRight: spacing['3'],
  },
  suggestionContent: {
    alignItems: 'center',
  },
  suggestionName: {
    marginVertical: spacing['2'],
    textAlign: 'center',
  },
  addButton: {
    paddingHorizontal: spacing['3'],
  },
  requestsSection: {
    marginBottom: spacing['4'],
  },
  requestCard: {
    marginBottom: spacing['3'],
  },
  requestCardContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  requestInfo: {
    flex: 1,
    marginLeft: spacing['3'],
  },
  requestActions: {
    flexDirection: 'row',
    gap: spacing['1'],
  },
  actionButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelButton: {
    paddingHorizontal: spacing['2'],
    paddingVertical: spacing['1'],
  },
});