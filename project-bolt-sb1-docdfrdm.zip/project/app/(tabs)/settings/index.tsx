import React, { useState } from 'react';
import { StyleSheet, Switch, TouchableOpacity, Platform } from 'react-native';
import { View, Text, Card, Avatar, Button } from '@/components/themed';
import useThemeStore from '@/store/themeStore';
import useUserStore from '@/store/userStore';
import Colors from '@/constants/Colors';
import spacing from '@/constants/Spacing';
import { Moon, Sun, BellRing, Shield, Map, Clock, ChevronRight, CircleHelp as HelpCircle, LogOut, Share2 } from 'lucide-react-native';
import { mockCurrentUser } from '@/utils/mockData';

export default function SettingsScreen() {
  const theme = useThemeStore(state => state.currentTheme());
  const colors = Colors[theme];
  
  // Theme control
  const { 
    toggleTheme, 
    setUseSystemTheme,
    useSystemTheme 
  } = useThemeStore();
  
  // User state
  const { 
    user, 
    setUser,
    isLocationSharing,
    setLocationSharing
  } = useUserStore();
  
  // Load mock user if not set
  React.useEffect(() => {
    if (!user) {
      setUser(mockCurrentUser);
    }
  }, []);
  
  // State
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [locationExpiration, setLocationExpiration] = useState<string>('8h');
  
  // Toggle system theme
  const handleSystemThemeToggle = (value: boolean) => {
    setUseSystemTheme(value);
  };
  
  // Toggle dark mode
  const handleDarkModeToggle = () => {
    toggleTheme();
  };
  
  // Toggle location sharing
  const handleLocationSharingToggle = (value: boolean) => {
    setLocationSharing(value);
  };
  
  // Toggle notifications
  const handleNotificationsToggle = (value: boolean) => {
    setNotificationsEnabled(value);
  };
  
  // Select location sharing expiration
  const handleExpirationSelect = (value: string) => {
    setLocationExpiration(value);
  };
  
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text variant="heading3">Settings</Text>
      </View>
      
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Profile Card */}
        <Card style={styles.profileCard}>
          <View style={styles.profileInfo}>
            <Avatar 
              source={{ uri: user?.avatar }} 
              size="lg"
              status="online"
            />
            
            <View style={styles.profileDetails}>
              <Text variant="title">{user?.name || 'User'}</Text>
              <Text variant="bodySmall" color={colors.text.secondary}>
                Location sharing: {isLocationSharing ? 'On' : 'Off'}
              </Text>
              
              <TouchableOpacity style={styles.editButton}>
                <Text variant="caption" color={colors.primary[500]}>
                  Edit Profile
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </Card>
        
        {/* Appearance Settings */}
        <View style={styles.section}>
          <Text variant="subtitle" style={styles.sectionTitle}>Appearance</Text>
          
          <Card style={styles.settingCard}>
            <View style={styles.settingRow}>
              <View style={styles.settingIconContainer}>
                <Moon size={20} color={theme === 'dark' ? colors.primary[500] : colors.text.secondary} />
              </View>
              
              <View style={styles.settingContent}>
                <Text variant="bodySmall">Use system theme</Text>
                <Text variant="caption" color={colors.text.secondary}>
                  Follow device settings
                </Text>
              </View>
              
              <Switch
                value={useSystemTheme}
                onValueChange={handleSystemThemeToggle}
                trackColor={{ false: colors.gray[300], true: colors.primary[300] }}
                thumbColor={useSystemTheme ? colors.primary[500] : colors.gray[100]}
              />
            </View>
            
            {!useSystemTheme && (
              <View style={[styles.settingRow, styles.settingDivider]}>
                <View style={styles.settingIconContainer}>
                  <Sun size={20} color={theme === 'light' ? colors.warning[500] : colors.text.secondary} />
                </View>
                
                <View style={styles.settingContent}>
                  <Text variant="bodySmall">Dark mode</Text>
                  <Text variant="caption" color={colors.text.secondary}>
                    {theme === 'dark' ? 'On' : 'Off'}
                  </Text>
                </View>
                
                <Switch
                  value={theme === 'dark'}
                  onValueChange={handleDarkModeToggle}
                  trackColor={{ false: colors.gray[300], true: colors.primary[300] }}
                  thumbColor={theme === 'dark' ? colors.primary[500] : colors.gray[100]}
                />
              </View>
            )}
          </Card>
        </View>
        
        {/* Privacy Settings */}
        <View style={styles.section}>
          <Text variant="subtitle" style={styles.sectionTitle}>Privacy & Location</Text>
          
          <Card style={styles.settingCard}>
            <View style={styles.settingRow}>
              <View style={styles.settingIconContainer}>
                <Share2 size={20} color={isLocationSharing ? colors.primary[500] : colors.text.secondary} />
              </View>
              
              <View style={styles.settingContent}>
                <Text variant="bodySmall">Share my location</Text>
                <Text variant="caption" color={colors.text.secondary}>
                  Allow friends to see where you are
                </Text>
              </View>
              
              <Switch
                value={isLocationSharing}
                onValueChange={handleLocationSharingToggle}
                trackColor={{ false: colors.gray[300], true: colors.primary[300] }}
                thumbColor={isLocationSharing ? colors.primary[500] : colors.gray[100]}
              />
            </View>
            
            {isLocationSharing && (
              <View style={[styles.settingRow, styles.settingDivider]}>
                <View style={styles.settingIconContainer}>
                  <Clock size={20} color={colors.text.secondary} />
                </View>
                
                <View style={styles.settingContent}>
                  <Text variant="bodySmall">Sharing expiration</Text>
                  <Text variant="caption" color={colors.text.secondary}>
                    Automatically stop after {locationExpiration}
                  </Text>
                </View>
                
                <TouchableOpacity style={styles.expirationSelector}>
                  <View style={styles.expirationOptions}>
                    {['2h', '8h', '24h', 'Never'].map(option => (
                      <TouchableOpacity
                        key={option}
                        style={[
                          styles.expirationOption,
                          option === locationExpiration && { 
                            backgroundColor: colors.primary[500],
                          }
                        ]}
                        onPress={() => handleExpirationSelect(option)}
                      >
                        <Text 
                          variant="caption" 
                          color={option === locationExpiration ? colors.text.inverse : colors.text.primary}
                        >
                          {option}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </TouchableOpacity>
              </View>
            )}
            
            <TouchableOpacity style={[styles.settingRow, styles.settingDivider]}>
              <View style={styles.settingIconContainer}>
                <Shield size={20} color={colors.text.secondary} />
              </View>
              
              <View style={styles.settingContent}>
                <Text variant="bodySmall">Privacy settings</Text>
                <Text variant="caption" color={colors.text.secondary}>
                  Control who can find and add you
                </Text>
              </View>
              
              <ChevronRight size={20} color={colors.text.tertiary} />
            </TouchableOpacity>
          </Card>
        </View>
        
        {/* Notification Settings */}
        <View style={styles.section}>
          <Text variant="subtitle" style={styles.sectionTitle}>Notifications</Text>
          
          <Card style={styles.settingCard}>
            <View style={styles.settingRow}>
              <View style={styles.settingIconContainer}>
                <BellRing size={20} color={notificationsEnabled ? colors.primary[500] : colors.text.secondary} />
              </View>
              
              <View style={styles.settingContent}>
                <Text variant="bodySmall">Push notifications</Text>
                <Text variant="caption" color={colors.text.secondary}>
                  Receive alerts when friends share location
                </Text>
              </View>
              
              <Switch
                value={notificationsEnabled}
                onValueChange={handleNotificationsToggle}
                trackColor={{ false: colors.gray[300], true: colors.primary[300] }}
                thumbColor={notificationsEnabled ? colors.primary[500] : colors.gray[100]}
              />
            </View>
            
            <TouchableOpacity style={[styles.settingRow, styles.settingDivider]}>
              <View style={styles.settingIconContainer}>
                <Map size={20} color={colors.text.secondary} />
              </View>
              
              <View style={styles.settingContent}>
                <Text variant="bodySmall">Geofence notifications</Text>
                <Text variant="caption" color={colors.text.secondary}>
                  Customize location-based alerts
                </Text>
              </View>
              
              <ChevronRight size={20} color={colors.text.tertiary} />
            </TouchableOpacity>
          </Card>
        </View>
        
        {/* Help & About */}
        <View style={styles.section}>
          <Text variant="subtitle" style={styles.sectionTitle}>Help & About</Text>
          
          <Card style={styles.settingCard}>
            <TouchableOpacity style={styles.settingRow}>
              <View style={styles.settingIconContainer}>
                <HelpCircle size={20} color={colors.text.secondary} />
              </View>
              
              <View style={styles.settingContent}>
                <Text variant="bodySmall">Help Center</Text>
                <Text variant="caption" color={colors.text.secondary}>
                  Get support and answers
                </Text>
              </View>
              
              <ChevronRight size={20} color={colors.text.tertiary} />
            </TouchableOpacity>
            
            <View style={[styles.settingRow, styles.settingDivider]}>
              <View style={styles.settingIconContainer}>
                <LogOut size={20} color={colors.error[500]} />
              </View>
              
              <View style={styles.settingContent}>
                <Text variant="bodySmall" color={colors.error[500]}>Sign Out</Text>
                <Text variant="caption" color={colors.text.secondary}>
                  Log out of your account
                </Text>
              </View>
            </View>
          </Card>
        </View>
        
        <View style={styles.versionContainer}>
          <Text variant="caption" color={colors.text.tertiary}>
            Find My Friends v1.0.0
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

// Import ScrollView after declaring it's used
import { ScrollView } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 60,
  },
  header: {
    paddingHorizontal: spacing['4'],
    paddingBottom: spacing['4'],
  },
  content: {
    flex: 1,
    paddingHorizontal: spacing['4'],
  },
  profileCard: {
    marginBottom: spacing['4'],
  },
  profileInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  profileDetails: {
    marginLeft: spacing['3'],
    flex: 1,
  },
  editButton: {
    marginTop: spacing['2'],
  },
  section: {
    marginBottom: spacing['4'],
  },
  sectionTitle: {
    marginBottom: spacing['2'],
    paddingHorizontal: spacing['1'],
  },
  settingCard: {
    overflow: 'hidden',
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing['3'],
  },
  settingDivider: {
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(0,0,0,0.05)',
  },
  settingIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.03)',
    marginRight: spacing['2'],
  },
  settingContent: {
    flex: 1,
  },
  expirationSelector: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  expirationOptions: {
    flexDirection: 'row',
    borderRadius: spacing['1'],
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.05)',
    overflow: 'hidden',
  },
  expirationOption: {
    paddingHorizontal: spacing['2'],
    paddingVertical: spacing['1'],
  },
  versionContainer: {
    alignItems: 'center',
    marginVertical: spacing['4'],
  }
});