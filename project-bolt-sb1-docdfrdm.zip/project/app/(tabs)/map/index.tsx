import React, { useRef, useState, useEffect } from 'react';
import { StyleSheet, Platform, Dimensions } from 'react-native';
import MapView, { Marker, Circle, PROVIDER_GOOGLE } from 'react-native-maps';
import { LinearGradient } from 'expo-linear-gradient';
import { View, Text, Button } from '@/components/themed';
import { FriendCard } from '@/components/themed';
import { LocationMarker } from '@/components/LocationMarker';
import { GeofenceCircle } from '@/components/GeofenceCircle';
import useThemeStore from '@/store/themeStore';
import Colors from '@/constants/Colors';
import spacing from '@/constants/Spacing';
import { Compass, Locate, Users, Plus, MapPin } from 'lucide-react-native';
import useLocation from '@/hooks/useLocation';
import useFriendLocation from '@/hooks/useFriendLocation';
import useGeofenceStore from '@/store/geofenceStore';
import { mockGeofences } from '@/utils/mockData';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withTiming,
  Easing,
} from 'react-native-reanimated';

// Map styles
const mapCustomStyle = [
  {
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#f5f5f5"
      }
    ]
  },
  {
    "elementType": "labels.icon",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#616161"
      }
    ]
  },
  {
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#f5f5f5"
      }
    ]
  },
  {
    "featureType": "administrative.land_parcel",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#bdbdbd"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#eeeeee"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#e5e5e5"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#9e9e9e"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#ffffff"
      }
    ]
  },
  {
    "featureType": "road.arterial",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dadada"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#616161"
      }
    ]
  },
  {
    "featureType": "road.local",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#9e9e9e"
      }
    ]
  },
  {
    "featureType": "transit.line",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#e5e5e5"
      }
    ]
  },
  {
    "featureType": "transit.station",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#eeeeee"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#c9c9c9"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#9e9e9e"
      }
    ]
  }
];

const darkMapStyle = [
  {
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#212121"
      }
    ]
  },
  {
    "elementType": "labels.icon",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#212121"
      }
    ]
  },
  {
    "featureType": "administrative",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "featureType": "administrative.country",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#9e9e9e"
      }
    ]
  },
  {
    "featureType": "administrative.land_parcel",
    "elementType": "labels",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "administrative.locality",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#bdbdbd"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "featureType": "poi.business",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#181818"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#616161"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#1b1b1b"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#2c2c2c"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "labels.icon",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#8a8a8a"
      }
    ]
  },
  {
    "featureType": "road.arterial",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#373737"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#3c3c3c"
      }
    ]
  },
  {
    "featureType": "road.highway.controlled_access",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#4e4e4e"
      }
    ]
  },
  {
    "featureType": "road.local",
    "elementType": "labels",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "road.local",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#616161"
      }
    ]
  },
  {
    "featureType": "transit",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "transit",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#000000"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#3d3d3d"
      }
    ]
  }
];

export default function MapScreen() {
  const theme = useThemeStore(state => state.currentTheme());
  const colors = Colors[theme];
  
  // Refs
  const mapRef = useRef<MapView>(null);
  
  // State
  const [selectedFriendId, setSelectedFriendId] = useState<string | null>(null);
  const [showFriendsList, setShowFriendsList] = useState(false);
  
  // Location hooks
  const { location, errorMsg, isLoading: isLocationLoading } = useLocation();
  const { sharingFriends } = useFriendLocation();
  
  // Geofence data
  const { 
    geofences, 
    activeGeofences, 
    setGeofences, 
    setActiveGeofences 
  } = useGeofenceStore();
  
  // Initialize geofence data
  useEffect(() => {
    if (geofences.length === 0) {
      setGeofences(mockGeofences);
      setActiveGeofences(mockGeofences.map(g => g.id));
    }
  }, []);
  
  // Animation values
  const friendsListHeight = useSharedValue(0);
  
  // Animated styles
  const friendsListStyle = useAnimatedStyle(() => {
    return {
      height: friendsListHeight.value,
      opacity: friendsListHeight.value > 0 ? 1 : 0,
    };
  });
  
  // Toggle friends list
  const toggleFriendsList = () => {
    const newValue = !showFriendsList;
    setShowFriendsList(newValue);
    
    friendsListHeight.value = withTiming(
      newValue ? 300 : 0,
      { duration: 300, easing: Easing.bezier(0.25, 0.1, 0.25, 1) }
    );
  };
  
  // Center map on user's location
  const centerOnUser = () => {
    if (location && mapRef.current) {
      mapRef.current.animateToRegion({
        latitude: location.latitude,
        longitude: location.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      }, 500);
    }
  };
  
  // Center map on a friend's location
  const centerOnFriend = (friendId: string) => {
    const friend = sharingFriends.find(f => f.id === friendId);
    
    if (friend?.location && mapRef.current) {
      mapRef.current.animateToRegion({
        latitude: friend.location.latitude,
        longitude: friend.location.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      }, 500);
      
      setSelectedFriendId(friendId);
      
      // Hide friends list after selecting
      if (showFriendsList) {
        toggleFriendsList();
      }
    }
  };
  
  // Show all friends on the map
  const showAllFriends = () => {
    if (sharingFriends.length === 0 || !mapRef.current) return;
    
    // Calculate bounds to fit all friends
    let minLat = 90, maxLat = -90, minLng = 180, maxLng = -180;
    
    // Include user location
    if (location) {
      minLat = Math.min(minLat, location.latitude);
      maxLat = Math.max(maxLat, location.latitude);
      minLng = Math.min(minLng, location.longitude);
      maxLng = Math.max(maxLng, location.longitude);
    }
    
    // Include all friends' locations
    sharingFriends.forEach(friend => {
      if (friend.location) {
        minLat = Math.min(minLat, friend.location.latitude);
        maxLat = Math.max(maxLat, friend.location.latitude);
        minLng = Math.min(minLng, friend.location.longitude);
        maxLng = Math.max(maxLng, friend.location.longitude);
      }
    });
    
    // Add padding
    const PADDING = 0.02;
    minLat -= PADDING;
    maxLat += PADDING;
    minLng -= PADDING;
    maxLng += PADDING;
    
    // Animate to the bounds
    mapRef.current.animateToRegion({
      latitude: (minLat + maxLat) / 2,
      longitude: (minLng + maxLng) / 2,
      latitudeDelta: maxLat - minLat,
      longitudeDelta: maxLng - minLng,
    }, 500);
    
    // Clear selection
    setSelectedFriendId(null);
  };
  
  // Initial positioning
  useEffect(() => {
    if (location && mapRef.current && !isLocationLoading) {
      // First center on user
      mapRef.current.animateToRegion({
        latitude: location.latitude,
        longitude: location.longitude,
        latitudeDelta: 0.02,
        longitudeDelta: 0.02,
      }, 500);
      
      // Then show all if there are sharing friends
      if (sharingFriends.length > 0) {
        setTimeout(showAllFriends, 1500);
      }
    }
  }, [location, isLocationLoading]);
  
  return (
    <View style={styles.container}>
      {/* Map View */}
      <MapView
        ref={mapRef}
        style={styles.map}
        provider={PROVIDER_GOOGLE}
        showsUserLocation
        showsMyLocationButton={false}
        showsCompass={false}
        showsScale={false}
        showsTraffic={false}
        customMapStyle={theme === 'dark' ? darkMapStyle : mapCustomStyle}
        initialRegion={{
          latitude: location?.latitude || 40.7128,
          longitude: location?.longitude || -74.0060,
          latitudeDelta: 0.02,
          longitudeDelta: 0.02,
        }}
      >
        {/* Friend markers */}
        {sharingFriends.map(friend => (
          friend.location && (
            <Marker
              key={friend.id}
              coordinate={{
                latitude: friend.location.latitude,
                longitude: friend.location.longitude,
              }}
              tracksViewChanges={false}
              onPress={() => setSelectedFriendId(friend.id)}
            >
              <LocationMarker 
                friend={friend} 
                isSelected={selectedFriendId === friend.id}
              />
            </Marker>
          )
        ))}
        
        {/* Geofence circles */}
        {geofences.map(geofence => (
          <Circle
            key={geofence.id}
            center={{
              latitude: geofence.location.latitude,
              longitude: geofence.location.longitude,
            }}
            radius={geofence.radius}
            strokeWidth={2}
            strokeColor={
              activeGeofences.includes(geofence.id) 
                ? colors.primary[300] 
                : colors.gray[300]
            }
            fillColor={
              activeGeofences.includes(geofence.id) 
                ? colors.primary[300] + '33' 
                : colors.gray[300] + '33'
            }
          />
        ))}
        
        {/* Geofence markers */}
        {geofences.map(geofence => (
          <Marker
            key={`marker-${geofence.id}`}
            coordinate={{
              latitude: geofence.location.latitude,
              longitude: geofence.location.longitude,
            }}
            tracksViewChanges={false}
          >
            <MapPin 
              size={24} 
              color={
                activeGeofences.includes(geofence.id) 
                  ? colors.primary[500] 
                  : colors.gray[500]
              } 
            />
          </Marker>
        ))}
      </MapView>
      
      {/* Map header - Gradient overlay */}
      <LinearGradient
        colors={[colors.background.primary, 'transparent']}
        style={styles.headerGradient}
      >
        <View style={styles.header}>
          <Text variant="title">Find My Friends</Text>
          
          {/* Show number of active friends */}
          <View style={styles.activeCount}>
            <Text variant="caption">
              {sharingFriends.length} {sharingFriends.length === 1 ? 'friend' : 'friends'} active
            </Text>
          </View>
        </View>
      </LinearGradient>
      
      {/* Friends List Panel */}
      <Animated.View style={[styles.friendsPanel, friendsListStyle]}>
        <View style={styles.friendsPanelContent}>
          <View style={styles.friendsPanelHeader}>
            <Text variant="subtitle">Your Friends</Text>
            <Text variant="caption" color={colors.text.secondary}>
              {sharingFriends.length} sharing location
            </Text>
          </View>
          
          {sharingFriends.length > 0 ? (
            <Animated.ScrollView 
              style={styles.friendsList}
              showsVerticalScrollIndicator={false}
            >
              {sharingFriends.map(friend => (
                <FriendCard
                  key={friend.id}
                  friend={friend}
                  onPress={() => centerOnFriend(friend.id)}
                  onLocationPress={() => centerOnFriend(friend.id)}
                />
              ))}
            </Animated.ScrollView>
          ) : (
            <View style={styles.emptyState}>
              <Text color={colors.text.secondary}>
                No friends sharing their location
              </Text>
            </View>
          )}
        </View>
      </Animated.View>
      
      {/* Control Buttons */}
      <View style={styles.controls}>
        {/* My Location Button */}
        <Button
          variant="primary"
          style={styles.controlButton}
          onPress={centerOnUser}
          icon={<Locate size={24} color={colors.text.inverse} />}
        />
        
        {/* Compass Button */}
        <Button
          variant="secondary"
          style={styles.controlButton}
          onPress={showAllFriends}
          icon={<Compass size={24} color={colors.text.inverse} />}
        />
        
        {/* Friends List Toggle */}
        <Button
          variant={showFriendsList ? 'primary' : 'outline'}
          style={styles.controlButton}
          onPress={toggleFriendsList}
          icon={<Users size={24} color={showFriendsList ? colors.text.inverse : colors.primary[500]} />}
        />
        
        {/* Add Geofence Button */}
        <Button
          variant="ghost"
          style={styles.controlButton}
          icon={<Plus size={24} color={colors.text.primary} />}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  headerGradient: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 120,
    paddingTop: Platform.OS === 'ios' ? 50 : 40,
  },
  header: {
    paddingHorizontal: spacing['4'],
    alignItems: 'center',
  },
  activeCount: {
    marginTop: spacing['1'],
  },
  controls: {
    position: 'absolute',
    right: spacing['4'],
    bottom: 100,
    alignItems: 'center',
    gap: spacing['2'],
  },
  controlButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  friendsPanel: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'transparent',
    overflow: 'hidden',
  },
  friendsPanelContent: {
    backgroundColor: Platform.select({
      ios: 'rgba(255, 255, 255, 0.85)',
      android: 'rgba(255, 255, 255, 0.95)',
      default: 'rgba(255, 255, 255, 0.95)',
    }),
    borderTopLeftRadius: spacing['3'],
    borderTopRightRadius: spacing['3'],
    padding: spacing['4'],
    paddingBottom: spacing['10'],
    height: '100%',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: -3 },
        shadowOpacity: 0.1,
        shadowRadius: 3,
      },
      android: {
        elevation: 10,
      },
      default: {
        boxShadow: '0px -3px 10px rgba(0, 0, 0, 0.1)',
      },
    }),
  },
  friendsPanelHeader: {
    marginBottom: spacing['3'],
  },
  friendsList: {
    flex: 1,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing['4'],
  },
});