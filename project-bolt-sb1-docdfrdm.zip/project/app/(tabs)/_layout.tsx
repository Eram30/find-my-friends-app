import React from 'react';
import { Tabs } from 'expo-router';
import Colors from '@/constants/Colors';
import useThemeStore from '@/store/themeStore';
import useFriendsStore from '@/store/friendsStore';
import { Tabbar } from '@/components/themed';
import { MapPin, UserRound, Bell, Settings } from 'lucide-react-native';

export default function TabLayout() {
  const theme = useThemeStore(state => state.currentTheme());
  const colors = Colors[theme];
  
  // Get the number of pending friend requests for the badge
  const friendRequests = useFriendsStore(state => 
    state.friendRequests.filter(r => r.status === 'pending' && r.receiverId === 'current-user')
  );
  
  const renderTabBar = ({ state, descriptors, navigation }) => {
    const tabs = [
      {
        key: 'map/index',
        label: 'Map',
        icon: <MapPin 
                size={24} 
                color={state.index === 0 ? colors.primary[500] : colors.text.secondary} 
              />,
      },
      {
        key: 'friends/index',
        label: 'Friends',
        icon: <UserRound 
                size={24} 
                color={state.index === 1 ? colors.primary[500] : colors.text.secondary} 
              />,
        badgeCount: friendRequests.length,
      },
      {
        key: 'notifications/index',
        label: 'Alerts',
        icon: <Bell 
                size={24} 
                color={state.index === 2 ? colors.primary[500] : colors.text.secondary} 
              />,
      },
      {
        key: 'settings/index',
        label: 'Settings',
        icon: <Settings 
                size={24} 
                color={state.index === 3 ? colors.primary[500] : colors.text.secondary} 
              />,
      },
    ];
    
    return (
      <Tabbar 
        tabs={tabs} 
        activeKey={state.routes[state.index].name}
        onTabPress={(key) => {
          const event = navigation.emit({
            type: 'tabPress',
            target: key,
          });
          
          const routeIndex = state.routes.findIndex(route => route.name === key);
          if (routeIndex !== -1 && !event.defaultPrevented) {
            navigation.navigate(key);
          }
        }}
      />
    );
  };

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
      }}
      tabBar={renderTabBar}
    >
      <Tabs.Screen name="map/index" />
      <Tabs.Screen name="friends/index" />
      <Tabs.Screen name="notifications/index" />
      <Tabs.Screen name="settings/index" />
    </Tabs>
  );
}