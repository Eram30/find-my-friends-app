import { Friend, FriendRequest, Geofence, User } from '@/types';

// Mock current user
export const mockCurrentUser: User = {
  id: 'current-user',
  name: 'You',
  avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg',
  status: 'online',
};

// New York City coordinates
const NYC_COORDS = {
  latitude: 40.7128,
  longitude: -74.0060,
};

// Helper to generate random coordinates near a center point
const generateRandomCoords = (centerLat: number, centerLng: number, radiusInKm = 5) => {
  // Earth radius in kilometers
  const earthRadius = 6371;
  
  // Convert radius from km to radians
  const radiusInRad = radiusInKm / earthRadius;
  
  // Random angle
  const randomAngle = Math.random() * Math.PI * 2;
  
  // Random distance within radius
  const randomDistance = Math.random() * radiusInRad;
  
  // Calculate offset
  const latOffset = randomDistance * Math.cos(randomAngle);
  const lngOffset = randomDistance * Math.sin(randomAngle) / Math.cos(centerLat * (Math.PI / 180));
  
  // Convert to degrees
  const newLat = centerLat + latOffset * (180 / Math.PI);
  const newLng = centerLng + lngOffset * (180 / Math.PI);
  
  return {
    latitude: newLat,
    longitude: newLng,
    accuracy: Math.floor(Math.random() * 50) + 10,
    timestamp: Date.now(),
  };
};

// Mock friends data
export const mockFriends: Friend[] = [
  {
    id: 'friend-1',
    name: 'Emma Johnson',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
    status: 'online',
    isSharing: true,
    location: generateRandomCoords(NYC_COORDS.latitude, NYC_COORDS.longitude, 2),
    lastLocationUpdate: new Date(),
    isFavorite: true,
  },
  {
    id: 'friend-2',
    name: 'James Smith',
    avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg',
    status: 'online',
    isSharing: true,
    location: generateRandomCoords(NYC_COORDS.latitude, NYC_COORDS.longitude, 3),
    lastLocationUpdate: new Date(Date.now() - 1000 * 60 * 5), // 5 mins ago
    isFavorite: false,
  },
  {
    id: 'friend-3',
    name: 'Sophia Williams',
    avatar: 'https://images.pexels.com/photos/712513/pexels-photo-712513.jpeg',
    status: 'away',
    isSharing: true,
    location: generateRandomCoords(NYC_COORDS.latitude, NYC_COORDS.longitude, 4),
    lastLocationUpdate: new Date(Date.now() - 1000 * 60 * 15), // 15 mins ago
    isFavorite: true,
  },
  {
    id: 'friend-4',
    name: 'Michael Brown',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
    status: 'offline',
    isSharing: false,
    lastLocationUpdate: new Date(Date.now() - 1000 * 60 * 60 * 3), // 3 hours ago
    isFavorite: false,
  },
  {
    id: 'friend-5',
    name: 'Olivia Miller',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
    status: 'online',
    isSharing: true,
    location: generateRandomCoords(NYC_COORDS.latitude, NYC_COORDS.longitude, 1),
    lastLocationUpdate: new Date(),
    isFavorite: false,
  }
];

// Mock friend requests
export const mockFriendRequests: FriendRequest[] = [
  {
    id: 'request-1',
    senderId: 'sender-1',
    receiverId: 'current-user',
    status: 'pending',
    timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 mins ago
  },
  {
    id: 'request-2',
    senderId: 'current-user',
    receiverId: 'receiver-1',
    status: 'pending',
    timestamp: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
  }
];

// Mock users that can be added as friends
export const mockUsers: User[] = [
  {
    id: 'user-1',
    name: 'Alexander Wilson',
    avatar: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg',
    status: 'online',
  },
  {
    id: 'user-2',
    name: 'Isabella Taylor',
    avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg',
    status: 'offline',
  },
  {
    id: 'user-3',
    name: 'Ethan Martinez',
    avatar: 'https://images.pexels.com/photos/937481/pexels-photo-937481.jpeg',
    status: 'online',
  }
];

// Mock geofences
export const mockGeofences: Geofence[] = [
  {
    id: 'geofence-1',
    userId: 'current-user',
    name: 'Home',
    location: {
      latitude: NYC_COORDS.latitude + 0.01,
      longitude: NYC_COORDS.longitude + 0.01,
    },
    radius: 200, // meters
    friendIds: ['friend-1', 'friend-3'],
    notifyOnEnter: true,
    notifyOnExit: true,
  },
  {
    id: 'geofence-2',
    userId: 'current-user',
    name: 'Work',
    location: {
      latitude: NYC_COORDS.latitude - 0.02,
      longitude: NYC_COORDS.longitude - 0.01,
    },
    radius: 500, // meters
    friendIds: ['friend-2', 'friend-5'],
    notifyOnEnter: true,
    notifyOnExit: false,
  }
];