export interface User {
  id: string;
  name: string;
  avatar: string;
  status?: 'online' | 'offline' | 'away';
  lastSeen?: Date;
}

export interface Location {
  latitude: number;
  longitude: number;
  altitude?: number;
  accuracy?: number;
  heading?: number;
  speed?: number;
  timestamp?: number;
}

export interface FriendRequest {
  id: string;
  senderId: string;
  receiverId: string;
  status: 'pending' | 'accepted' | 'rejected';
  timestamp: Date;
}

export interface Friend extends User {
  location?: Location;
  isSharing: boolean;
  sharingExpiresAt?: Date;
  isFavorite?: boolean;
  lastLocationUpdate?: Date;
}

export interface Geofence {
  id: string;
  userId: string;
  name: string;
  location: Location;
  radius: number;
  friendIds: string[];
  notifyOnEnter: boolean;
  notifyOnExit: boolean;
}

export interface Notification {
  id: string;
  type: 'friendRequest' | 'locationSharing' | 'geofence' | 'system';
  title: string;
  message: string;
  read: boolean;
  timestamp: Date;
  data?: any;
}