// Spacing system based on 8px scale
export const spacing = {
  '0': 0,
  '0.5': 4,
  '1': 8,
  '1.5': 12,
  '2': 16,
  '2.5': 20,
  '3': 24,
  '3.5': 28,
  '4': 32,
  '5': 40,
  '6': 48,
  '7': 56,
  '8': 64,
  '9': 72,
  '10': 80,
  '12': 96,
  '14': 112,
  '16': 128,
  '20': 160,
  '24': 192,
  '28': 224,
  '32': 256,
  '36': 288,
  '40': 320,
  '44': 352,
  '48': 384,
  '52': 416,
  '56': 448,
  '60': 480,
  '64': 512,
  '72': 576,
  '80': 640,
  '96': 768,
} as const;

export type SpacingKey = keyof typeof spacing;

export const insets = {
  screen: {
    padding: spacing['4'],
  },
  card: {
    padding: spacing['4'],
    borderRadius: spacing['2'],
  },
  button: {
    paddingHorizontal: spacing['4'],
    paddingVertical: spacing['2.5'],
    borderRadius: spacing['1.5'],
  },
  input: {
    paddingHorizontal: spacing['3'],
    paddingVertical: spacing['2'],
    borderRadius: spacing['1.5'],
  },
};

export default spacing;