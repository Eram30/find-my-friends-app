export type ColorScheme = 'light' | 'dark';

export interface ThemeColors {
  primary: {
    50: string;
    100: string;
    200: string;
    300: string;
    400: string;
    500: string;
    600: string;
    700: string;
    800: string;
    900: string;
  };
  secondary: {
    50: string;
    100: string;
    200: string;
    300: string;
    400: string;
    500: string;
    600: string;
    700: string;
    800: string;
    900: string;
  };
  accent: {
    50: string;
    100: string;
    200: string;
    300: string;
    400: string;
    500: string;
    600: string;
    700: string;
    800: string;
    900: string;
  };
  success: {
    50: string;
    100: string;
    200: string;
    300: string;
    400: string;
    500: string;
    600: string;
    700: string;
    800: string;
    900: string;
  };
  warning: {
    50: string;
    100: string;
    200: string;
    300: string;
    400: string;
    500: string;
    600: string;
    700: string;
    800: string;
    900: string;
  };
  error: {
    50: string;
    100: string;
    200: string;
    300: string;
    400: string;
    500: string;
    600: string;
    700: string;
    800: string;
    900: string;
  };
  gray: {
    50: string;
    100: string;
    200: string;
    300: string;
    400: string;
    500: string;
    600: string;
    700: string;
    800: string;
    900: string;
  };
  text: {
    primary: string;
    secondary: string;
    tertiary: string;
    inverse: string;
  };
  background: {
    primary: string;
    secondary: string;
    tertiary: string;
    card: string;
    input: string;
  };
  border: {
    light: string;
    medium: string;
    dark: string;
  };
  shadow: {
    color: string;
    opacity: number;
  };
}

export interface ColorThemes {
  light: ThemeColors;
  dark: ThemeColors;
}

const Colors: ColorThemes = {
  light: {
    primary: {
      50: '#EBF5FF',
      100: '#D5E9FF',
      200: '#AAD2FF',
      300: '#7FBAFF',
      400: '#54A2FF',
      500: '#2A8AFF', // Primary blue
      600: '#1F6FD6',
      700: '#1355AD',
      800: '#0A3B84',
      900: '#00205B',
    },
    secondary: {
      50: '#E4F8FA',
      100: '#C9F0F5',
      200: '#97E5EF',
      300: '#64D9E9',
      400: '#32CDE2',
      500: '#00C2DB', // Secondary teal
      600: '#009CB8',
      700: '#007795',
      800: '#005272',
      900: '#002D4F',
    },
    accent: {
      50: '#FFF2EB',
      100: '#FFE5D6',
      200: '#FFCBAE',
      300: '#FFB185',
      400: '#FF975D',
      500: '#FF7D34', // Accent orange
      600: '#EB6420',
      700: '#B64C14',
      800: '#92380B',
      900: '#6D2500',
    },
    success: {
      50: '#ECFDF5',
      100: '#D1FAE5',
      200: '#A7F3D0',
      300: '#6EE7B7',
      400: '#34D399',
      500: '#10B981', // Success green
      600: '#059669',
      700: '#047857',
      800: '#065F46',
      900: '#064E3B',
    },
    warning: {
      50: '#FFFBEB',
      100: '#FEF3C7',
      200: '#FDE68A',
      300: '#FCD34D',
      400: '#FBBF24',
      500: '#F59E0B', // Warning yellow
      600: '#D97706',
      700: '#B45309',
      800: '#92400E',
      900: '#78350F',
    },
    error: {
      50: '#FEF2F2',
      100: '#FEE2E2',
      200: '#FECACA',
      300: '#FCA5A5',
      400: '#F87171',
      500: '#EF4444', // Error red
      600: '#DC2626',
      700: '#B91C1C',
      800: '#991B1B',
      900: '#7F1D1D',
    },
    gray: {
      50: '#F9FAFB',
      100: '#F3F4F6',
      200: '#E5E7EB',
      300: '#D1D5DB',
      400: '#9CA3AF',
      500: '#6B7280',
      600: '#4B5563',
      700: '#374151',
      800: '#1F2937',
      900: '#111827',
    },
    text: {
      primary: '#1F2937',
      secondary: '#4B5563',
      tertiary: '#9CA3AF',
      inverse: '#FFFFFF',
    },
    background: {
      primary: '#FFFFFF',
      secondary: '#F9FAFB',
      tertiary: '#F3F4F6',
      card: '#FFFFFF',
      input: '#F9FAFB',
    },
    border: {
      light: '#E5E7EB',
      medium: '#D1D5DB',
      dark: '#9CA3AF',
    },
    shadow: {
      color: '#000000',
      opacity: 0.05,
    },
  },
  dark: {
    primary: {
      50: '#0A3B84',
      100: '#1355AD',
      200: '#1F6FD6',
      300: '#2A8AFF',
      400: '#54A2FF',
      500: '#7FBAFF', // Primary blue
      600: '#AAD2FF',
      700: '#D5E9FF',
      800: '#EBF5FF',
      900: '#F5FAFF',
    },
    secondary: {
      50: '#002D4F',
      100: '#005272',
      200: '#007795',
      300: '#009CB8',
      400: '#00C2DB',
      500: '#32CDE2', // Secondary teal
      600: '#64D9E9',
      700: '#97E5EF',
      800: '#C9F0F5',
      900: '#E4F8FA',
    },
    accent: {
      50: '#6D2500',
      100: '#92380B',
      200: '#B64C14',
      300: '#EB6420',
      400: '#FF7D34',
      500: '#FF975D', // Accent orange
      600: '#FFB185',
      700: '#FFCBAE',
      800: '#FFE5D6',
      900: '#FFF2EB',
    },
    success: {
      50: '#064E3B',
      100: '#065F46',
      200: '#047857',
      300: '#059669',
      400: '#10B981',
      500: '#34D399', // Success green
      600: '#6EE7B7',
      700: '#A7F3D0',
      800: '#D1FAE5',
      900: '#ECFDF5',
    },
    warning: {
      50: '#78350F',
      100: '#92400E',
      200: '#B45309',
      300: '#D97706',
      400: '#F59E0B',
      500: '#FBBF24', // Warning yellow
      600: '#FCD34D',
      700: '#FDE68A',
      800: '#FEF3C7',
      900: '#FFFBEB',
    },
    error: {
      50: '#7F1D1D',
      100: '#991B1B',
      200: '#B91C1C',
      300: '#DC2626',
      400: '#EF4444',
      500: '#F87171', // Error red
      600: '#FCA5A5',
      700: '#FECACA',
      800: '#FEE2E2',
      900: '#FEF2F2',
    },
    gray: {
      900: '#F9FAFB',
      800: '#F3F4F6',
      700: '#E5E7EB',
      600: '#D1D5DB',
      500: '#9CA3AF',
      400: '#6B7280',
      300: '#4B5563',
      200: '#374151',
      100: '#1F2937',
      50: '#111827',
    },
    text: {
      primary: '#F9FAFB',
      secondary: '#E5E7EB',
      tertiary: '#9CA3AF',
      inverse: '#111827',
    },
    background: {
      primary: '#111827',
      secondary: '#1F2937',
      tertiary: '#374151',
      card: '#1F2937',
      input: '#374151',
    },
    border: {
      light: '#4B5563',
      medium: '#6B7280',
      dark: '#9CA3AF',
    },
    shadow: {
      color: '#000000',
      opacity: 0.2,
    },
  },
};

export default Colors;