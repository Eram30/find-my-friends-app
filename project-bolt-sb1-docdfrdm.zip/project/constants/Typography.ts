import { TextStyle } from 'react-native';

export type FontWeight = 'normal' | 'medium' | 'bold';

interface Typography {
  fontFamily: {
    normal: string;
    medium: string;
    bold: string;
  };
  fontSize: {
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    '2xl': number;
    '3xl': number;
    '4xl': number;
    '5xl': number;
    '6xl': number;
  };
  lineHeight: {
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    '2xl': number;
    '3xl': number;
    '4xl': number;
    '5xl': number;
    '6xl': number;
  };
}

const typography: Typography = {
  fontFamily: {
    normal: 'Inter-Regular',
    medium: 'Inter-Medium',
    bold: 'Inter-Bold',
  },
  fontSize: {
    xs: 12,
    sm: 14,
    md: 16,
    lg: 18,
    xl: 20,
    '2xl': 24,
    '3xl': 30,
    '4xl': 36,
    '5xl': 48,
    '6xl': 60,
  },
  lineHeight: {
    xs: 16,
    sm: 20,
    md: 24,
    lg: 28,
    xl: 28,
    '2xl': 32,
    '3xl': 36,
    '4xl': 40,
    '5xl': 54,
    '6xl': 72,
  },
};

type TextVariant =
  | 'heading1'
  | 'heading2'
  | 'heading3'
  | 'heading4'
  | 'title'
  | 'subtitle'
  | 'body'
  | 'bodySmall'
  | 'caption'
  | 'button';

export const createTextStyle = (
  fontSize: keyof Typography['fontSize'],
  fontWeight: FontWeight = 'normal',
  lineHeightKey?: keyof Typography['lineHeight']
): TextStyle => {
  return {
    fontFamily: typography.fontFamily[fontWeight],
    fontSize: typography.fontSize[fontSize],
    lineHeight: typography.lineHeight[lineHeightKey || fontSize],
  };
};

export const textVariants: Record<TextVariant, TextStyle> = {
  heading1: createTextStyle('4xl', 'bold'),
  heading2: createTextStyle('3xl', 'bold'),
  heading3: createTextStyle('2xl', 'bold'),
  heading4: createTextStyle('xl', 'bold'),
  title: createTextStyle('lg', 'medium'),
  subtitle: createTextStyle('md', 'medium'),
  body: createTextStyle('md', 'normal'),
  bodySmall: createTextStyle('sm', 'normal'),
  caption: createTextStyle('xs', 'normal'),
  button: createTextStyle('md', 'medium'),
};

export default typography;