import React from 'react';
import { StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { View } from './View';
import { Text } from './Text';
import { Card } from './Card';
import { Avatar } from './Avatar';
import { Friend } from '@/types';
import Colors from '@/constants/Colors';
import useThemeStore from '@/store/themeStore';
import spacing from '@/constants/Spacing';
import { Map, Share2, Star } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';

type FriendCardProps = {
  friend: Friend;
  onPress?: () => void;
  onLocationPress?: () => void;
  onSharePress?: () => void;
  onFavoritePress?: () => void;
};

export function FriendCard({ 
  friend, 
  onPress, 
  onLocationPress,
  onSharePress,
  onFavoritePress,
}: FriendCardProps) {
  const theme = useThemeStore(state => state.currentTheme());
  const colors = Colors[theme];
  
  const handlePress = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    onPress?.();
  };
  
  // Calculate time since last location update
  const getTimeAgo = () => {
    if (!friend.lastLocationUpdate) return 'Never';
    
    const now = new Date();
    const lastUpdate = new Date(friend.lastLocationUpdate);
    const diffMs = now.getTime() - lastUpdate.getTime();
    
    const diffSecs = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffSecs / 60);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffDays > 0) return `${diffDays}d ago`;
    if (diffHours > 0) return `${diffHours}h ago`;
    if (diffMins > 0) return `${diffMins}m ago`;
    return 'Just now';
  };
  
  return (
    <TouchableOpacity
      activeOpacity={0.7}
      onPress={handlePress}
    >
      <Card style={styles.card}>
        <View style={styles.cardContent}>
          {/* Avatar with status */}
          <Avatar 
            source={{ uri: friend.avatar }} 
            size="md" 
            status={friend.status}
          />
          
          {/* Friend info */}
          <View style={styles.info}>
            <Text variant="subtitle" numberOfLines={1}>{friend.name}</Text>
            
            <View style={styles.statusContainer}>
              <View 
                style={[
                  styles.indicator, 
                  { 
                    backgroundColor: friend.isSharing ? 
                      colors.success[500] : 
                      colors.gray[400] 
                  }
                ]} 
              />
              <Text 
                variant="caption" 
                color={colors.text.secondary}
                numberOfLines={1}
              >
                {friend.isSharing ? 
                  `Sharing location · ${getTimeAgo()}` : 
                  'Not sharing location'}
              </Text>
            </View>
          </View>
          
          {/* Action buttons */}
          <View style={styles.actions}>
            {/* Favorite toggle */}
            <TouchableOpacity
              style={styles.actionButton}
              onPress={onFavoritePress}
            >
              <Star 
                size={20} 
                color={friend.isFavorite ? colors.warning[500] : colors.gray[400]}
                fill={friend.isFavorite ? colors.warning[500] : 'none'}
              />
            </TouchableOpacity>
            
            {/* Share location button */}
            <TouchableOpacity
              style={styles.actionButton}
              onPress={onSharePress}
              disabled={!friend.isSharing}
            >
              <Share2 
                size={20} 
                color={friend.isSharing ? colors.primary[500] : colors.gray[300]}
              />
            </TouchableOpacity>
            
            {/* View on map button */}
            <TouchableOpacity
              style={styles.actionButton}
              onPress={onLocationPress}
              disabled={!friend.location}
            >
              <Map 
                size={20} 
                color={friend.location ? colors.primary[500] : colors.gray[300]}
              />
            </TouchableOpacity>
          </View>
        </View>
      </Card>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    marginBottom: spacing['3'],
  },
  cardContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  info: {
    flex: 1,
    marginLeft: spacing['3'],
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing['0.5'],
  },
  indicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: spacing['1'],
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
});