import React from 'react';
import { StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { BlurView } from 'expo-blur';
import { View } from './View';
import { Text } from './Text';
import Colors from '@/constants/Colors';
import useThemeStore from '@/store/themeStore';
import spacing from '@/constants/Spacing';
import * as Haptics from 'expo-haptics';

export type TabItem = {
  key: string;
  label?: string;
  icon: React.ReactNode;
  badgeCount?: number;
};

type TabbarProps = {
  tabs: TabItem[];
  activeKey: string;
  onTabPress: (key: string) => void;
};

export function Tabbar({ tabs, activeKey, onTabPress }: TabbarProps) {
  const theme = useThemeStore(state => state.currentTheme());
  const colors = Colors[theme];
  
  const handleTabPress = (key: string) => {
    // Trigger haptic feedback on tab press
    if (Platform.OS !== 'web') {
      Haptics.selectionAsync();
    }
    
    onTabPress(key);
  };
  
  // Check if we can use BlurView (not on web)
  const canUseBlur = Platform.OS !== 'web';
  
  return (
    <View style={styles.container}>
      {canUseBlur ? (
        <BlurView
          intensity={80}
          tint={theme === 'dark' ? 'dark' : 'light'}
          style={[
            styles.blurContainer,
            { 
              borderTopColor: colors.border.light,
            }
          ]}
        >
          {renderTabs()}
        </BlurView>
      ) : (
        <View
          style={[
            styles.solidContainer,
            { 
              backgroundColor: colors.background.primary,
              borderTopColor: colors.border.light,
            }
          ]}
        >
          {renderTabs()}
        </View>
      )}
    </View>
  );
  
  function renderTabs() {
    return tabs.map((tab) => {
      const isActive = tab.key === activeKey;
      
      return (
        <TouchableOpacity
          key={tab.key}
          style={styles.tab}
          onPress={() => handleTabPress(tab.key)}
          activeOpacity={0.7}
        >
          <View style={styles.tabContent}>
            {/* Icon */}
            <View 
              style={[
                styles.iconContainer,
                isActive && { 
                  backgroundColor: colors.primary[theme === 'dark' ? 900 : 50],
                }
              ]}
            >
              {tab.icon}
              
              {/* Badge (if any) */}
              {!!tab.badgeCount && (
                <View
                  style={[
                    styles.badge,
                    { backgroundColor: colors.error[500] }
                  ]}
                >
                  <Text variant="caption" color={colors.text.inverse} style={styles.badgeText}>
                    {tab.badgeCount > 99 ? '99+' : tab.badgeCount}
                  </Text>
                </View>
              )}
            </View>
            
            {/* Label (if any) */}
            {tab.label && (
              <Text
                variant="caption"
                color={isActive ? colors.primary[500] : colors.text.secondary}
              >
                {tab.label}
              </Text>
            )}
          </View>
        </TouchableOpacity>
      );
    });
  }
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
  },
  blurContainer: {
    flexDirection: 'row',
    borderTopWidth: StyleSheet.hairlineWidth,
    paddingBottom: Platform.OS === 'ios' ? spacing['5'] : spacing['2'],
  },
  solidContainer: {
    flexDirection: 'row',
    borderTopWidth: StyleSheet.hairlineWidth,
    paddingBottom: Platform.OS === 'ios' ? spacing['5'] : spacing['2'],
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing['2'],
  },
  tabContent: {
    alignItems: 'center',
    gap: spacing['0.5'],
  },
  iconContainer: {
    padding: spacing['1'],
    borderRadius: spacing['1.5'],
  },
  badge: {
    position: 'absolute',
    top: -4,
    right: -4,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    fontSize: 10,
    fontWeight: '600',
  },
});