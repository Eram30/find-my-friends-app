import { Text as DefaultText, TextProps as DefaultTextProps } from 'react-native';
import Colors from '@/constants/Colors';
import useThemeStore from '@/store/themeStore';
import { textVariants } from '@/constants/Typography';

export type TextProps = DefaultTextProps & {
  variant?: keyof typeof textVariants;
  color?: string;
  weight?: 'normal' | 'medium' | 'bold';
};

export function Text({ 
  style, 
  variant = 'body', 
  color, 
  weight,
  ...otherProps 
}: TextProps) {
  const theme = useThemeStore(state => state.currentTheme());
  const colors = Colors[theme];
  
  // Get the base style from the variant
  const variantStyle = textVariants[variant];
  
  // If weight is specified, override the fontFamily from the variant
  const fontFamily = weight ? 
    { fontFamily: `Inter-${weight === 'normal' ? 'Regular' : weight === 'medium' ? 'Medium' : 'Bold'}` } : 
    {};
  
  // Default to text.primary color unless overridden
  const colorStyle = { color: color || colors.text.primary };
  
  return (
    <DefaultText
      style={[variantStyle, fontFamily, colorStyle, style]}
      {...otherProps}
    />
  );
}