import React from 'react';
import { StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { View } from './View';
import { Text } from './Text';
import { Card } from './Card';
import { Geofence } from '@/types';
import Colors from '@/constants/Colors';
import useThemeStore from '@/store/themeStore';
import spacing from '@/constants/Spacing';
import { ToggleLeft, ToggleRight, MapPin, User, CreditCard as Edit } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import useFriendsStore from '@/store/friendsStore';

type GeofenceCardProps = {
  geofence: Geofence;
  isActive?: boolean;
  onPress?: () => void;
  onToggle?: () => void;
  onEdit?: () => void;
};

export function GeofenceCard({ 
  geofence, 
  isActive = false,
  onPress, 
  onToggle,
  onEdit,
}: GeofenceCardProps) {
  const theme = useThemeStore(state => state.currentTheme());
  const colors = Colors[theme];
  const friends = useFriendsStore(state => state.friends);
  
  const handlePress = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    onPress?.();
  };
  
  // Get number of monitored friends
  const friendCount = geofence.friendIds.length;
  
  // Get friend names
  const getFriendNames = () => {
    const monitoredFriends = friends.filter(f => geofence.friendIds.includes(f.id));
    
    if (monitoredFriends.length === 0) return 'No friends monitored';
    
    if (monitoredFriends.length === 1) return monitoredFriends[0].name;
    
    if (monitoredFriends.length === 2) {
      return `${monitoredFriends[0].name} and ${monitoredFriends[1].name}`;
    }
    
    return `${monitoredFriends[0].name}, ${monitoredFriends[1].name}, and ${monitoredFriends.length - 2} more`;
  };
  
  return (
    <TouchableOpacity
      activeOpacity={0.7}
      onPress={handlePress}
    >
      <Card style={styles.card}>
        <View style={styles.cardHeader}>
          <View style={styles.titleContainer}>
            <MapPin size={20} color={colors.primary[500]} />
            <Text variant="subtitle" numberOfLines={1}>{geofence.name}</Text>
          </View>
          
          <TouchableOpacity onPress={onToggle}>
            {isActive ? (
              <ToggleRight size={24} color={colors.success[500]} />
            ) : (
              <ToggleLeft size={24} color={colors.gray[400]} />
            )}
          </TouchableOpacity>
        </View>
        
        <View style={styles.cardContent}>
          <View style={styles.infoRow}>
            <View style={styles.infoItem}>
              <View style={styles.infoIcon}>
                <User size={16} color={colors.text.secondary} />
              </View>
              <Text variant="bodySmall" color={colors.text.secondary}>
                {friendCount} {friendCount === 1 ? 'friend' : 'friends'}
              </Text>
            </View>
            
            <View style={styles.infoItem}>
              <Text variant="bodySmall" color={colors.text.secondary}>
                {geofence.radius}m radius
              </Text>
            </View>
          </View>
          
          <Text variant="bodySmall" numberOfLines={2} style={styles.friendNames}>
            {getFriendNames()}
          </Text>
          
          <View style={styles.footer}>
            <Text 
              variant="caption" 
              color={isActive ? colors.success[500] : colors.text.tertiary}
            >
              {isActive ? 'Active' : 'Inactive'}
            </Text>
            
            <TouchableOpacity style={styles.editButton} onPress={onEdit}>
              <Edit size={16} color={colors.primary[500]} />
              <Text variant="caption" color={colors.primary[500]}>Edit</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Card>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    marginBottom: spacing['3'],
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: spacing['2'],
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing['1'],
  },
  cardContent: {
    gap: spacing['2'],
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing['1'],
  },
  infoIcon: {
    width: 20,
    height: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  friendNames: {
    marginTop: spacing['1'],
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing['1'],
  },
  editButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing['1'],
    padding: spacing['1'],
  },
});