import React from 'react';
import { StyleSheet, ViewStyle } from 'react-native';
import { View, ViewProps } from './View';
import Colors from '@/constants/Colors';
import useThemeStore from '@/store/themeStore';
import spacing from '@/constants/Spacing';

export type CardProps = ViewProps & {
  variant?: 'elevated' | 'outlined' | 'filled';
  size?: 'sm' | 'md' | 'lg';
};

export function Card({ 
  style, 
  variant = 'elevated', 
  size = 'md',
  children,
  ...otherProps 
}: CardProps) {
  const theme = useThemeStore(state => state.currentTheme());
  const colors = Colors[theme];
  
  // Determine padding based on size
  const sizePadding: Record<CardProps['size'], number> = {
    sm: spacing['3'],
    md: spacing['4'],
    lg: spacing['5'],
  };
  
  // Base styles for all cards
  const baseStyle: ViewStyle = {
    borderRadius: spacing['2'],
    padding: sizePadding[size],
  };
  
  // Variant-specific styles
  const variantStyles: Record<CardProps['variant'], ViewStyle> = {
    elevated: {
      backgroundColor: colors.background.card,
      shadowColor: colors.shadow.color,
      shadowOpacity: colors.shadow.opacity,
      shadowOffset: { width: 0, height: 2 },
      shadowRadius: 8,
      elevation: 4,
    },
    outlined: {
      backgroundColor: colors.background.card,
      borderWidth: 1,
      borderColor: colors.border.light,
    },
    filled: {
      backgroundColor: colors.background.secondary,
    },
  };
  
  return (
    <View
      style={[baseStyle, variantStyles[variant], style]}
      {...otherProps}
    >
      {children}
    </View>
  );
}

const styles = StyleSheet.create({});