import { View as DefaultView, ViewProps as DefaultViewProps } from 'react-native';
import Colors from '@/constants/Colors';
import useThemeStore from '@/store/themeStore';

export type ViewProps = DefaultViewProps & {
  bgColor?: string;
  border?: boolean;
  borderColor?: string;
};

export function View({ 
  style, 
  bgColor, 
  border = false,
  borderColor,
  ...otherProps 
}: ViewProps) {
  const theme = useThemeStore(state => state.currentTheme());
  const colors = Colors[theme];
  
  const backgroundColor = bgColor || colors.background.primary;
  
  const borderStyle = border ? {
    borderWidth: 1,
    borderColor: borderColor || colors.border.light,
  } : {};
  
  return (
    <DefaultView
      style={[{ backgroundColor }, borderStyle, style]}
      {...otherProps}
    />
  );
}