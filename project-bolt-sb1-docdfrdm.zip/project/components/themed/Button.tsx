import React from 'react';
import { 
  StyleSheet, 
  TouchableOpacity, 
  TouchableOpacityProps,
  ActivityIndicator,
  Platform,
  ViewStyle
} from 'react-native';
import { Text } from './Text';
import { View } from './View';
import Colors from '@/constants/Colors';
import useThemeStore from '@/store/themeStore';
import spacing from '@/constants/Spacing';
import * as Haptics from 'expo-haptics';

export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md' | 'lg';

export type ButtonProps = TouchableOpacityProps & {
  variant?: ButtonVariant;
  size?: ButtonSize;
  label?: string;
  loading?: boolean;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
  disabled?: boolean;
};

export function Button({ 
  style, 
  variant = 'primary',
  size = 'md',
  label,
  loading = false,
  icon,
  iconPosition = 'left',
  fullWidth = false,
  disabled = false,
  onPress,
  children,
  ...otherProps 
}: ButtonProps) {
  const theme = useThemeStore(state => state.currentTheme());
  const colors = Colors[theme];
  
  // Handle haptic feedback on press
  const handlePress = (e: any) => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    if (onPress) {
      onPress(e);
    }
  };
  
  // Button height and padding based on size
  const sizeStyles: Record<ButtonSize, ViewStyle> = {
    sm: {
      paddingVertical: spacing['1.5'],
      paddingHorizontal: spacing['2'],
      borderRadius: spacing['1'],
    },
    md: {
      paddingVertical: spacing['2'],
      paddingHorizontal: spacing['3'],
      borderRadius: spacing['1.5'],
    },
    lg: {
      paddingVertical: spacing['3'],
      paddingHorizontal: spacing['4'],
      borderRadius: spacing['2'],
    },
  };
  
  // Button variants
  const getBackgroundColor = (): string => {
    if (disabled) return colors.gray[300];
    
    switch (variant) {
      case 'primary':
        return colors.primary[500];
      case 'secondary':
        return colors.secondary[500];
      case 'danger':
        return colors.error[500];
      case 'outline':
      case 'ghost':
        return 'transparent';
      default:
        return colors.primary[500];
    }
  };
  
  const getTextColor = (): string => {
    if (disabled) return colors.gray[500];
    
    switch (variant) {
      case 'primary':
      case 'secondary':
      case 'danger':
        return colors.text.inverse;
      case 'outline':
        return colors.primary[500];
      case 'ghost':
        return colors.text.primary;
      default:
        return colors.text.inverse;
    }
  };
  
  const getBorderStyle = (): ViewStyle => {
    if (variant === 'outline') {
      return {
        borderWidth: 1,
        borderColor: disabled ? colors.gray[300] : colors.primary[500],
      };
    }
    return {};
  };
  
  // Get content spacing based on what's being rendered
  const getContentStyle = (): ViewStyle => {
    const hasLabel = !!label || !!children;
    const hasIcon = !!icon;
    
    if (hasLabel && hasIcon) {
      return {
        flexDirection: iconPosition === 'left' ? 'row' : 'row-reverse',
        alignItems: 'center',
        justifyContent: 'center',
        gap: spacing['2'],
      };
    }
    
    return {
      alignItems: 'center',
      justifyContent: 'center',
    };
  };
  
  return (
    <TouchableOpacity
      style={[
        styles.button,
        sizeStyles[size],
        getBorderStyle(),
        { backgroundColor: getBackgroundColor() },
        fullWidth && styles.fullWidth,
        disabled && styles.disabled,
        style,
      ]}
      onPress={handlePress}
      disabled={disabled || loading}
      activeOpacity={0.7}
      {...otherProps}
    >
      <View style={[getContentStyle(), { backgroundColor: 'transparent' }]}>
        {loading ? (
          <ActivityIndicator 
            size="small" 
            color={getTextColor()} 
          />
        ) : (
          <>
            {icon}
            {(label || children) && (
              <Text 
                variant="button" 
                color={getTextColor()}
              >
                {label || children}
              </Text>
            )}
          </>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  fullWidth: {
    width: '100%',
  },
  disabled: {
    opacity: 0.7,
  },
});