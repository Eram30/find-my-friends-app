import React from 'react';
import { StyleSheet, Image, ImageSourcePropType, ViewStyle } from 'react-native';
import { View } from './View';
import Colors from '@/constants/Colors';
import useThemeStore from '@/store/themeStore';
import spacing from '@/constants/Spacing';

type AvatarSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

type AvatarProps = {
  source: ImageSourcePropType;
  size?: AvatarSize;
  status?: 'online' | 'offline' | 'away';
  style?: ViewStyle;
  borderColor?: string;
};

export function Avatar({ 
  source, 
  size = 'md', 
  status,
  style,
  borderColor,
}: AvatarProps) {
  const theme = useThemeStore(state => state.currentTheme());
  const colors = Colors[theme];
  
  // Determine avatar dimensions based on size
  const sizeMap: Record<AvatarSize, number> = {
    xs: spacing['6'],
    sm: spacing['8'],
    md: spacing['10'],
    lg: spacing['14'],
    xl: spacing['20'],
  };
  
  // Determine status indicator dimensions based on avatar size
  const statusSizeMap: Record<AvatarSize, number> = {
    xs: spacing['1.5'],
    sm: spacing['2'],
    md: spacing['2.5'],
    lg: spacing['3'],
    xl: spacing['3.5'],
  };
  
  // Get status color
  const getStatusColor = () => {
    switch (status) {
      case 'online':
        return colors.success[500];
      case 'offline':
        return colors.gray[400];
      case 'away':
        return colors.warning[500];
      default:
        return colors.gray[400];
    }
  };
  
  const avatarSize = sizeMap[size];
  const statusSize = statusSizeMap[size];
  
  return (
    <View 
      style={[
        styles.container,
        {
          width: avatarSize,
          height: avatarSize,
          borderRadius: avatarSize / 2,
          borderColor: borderColor || colors.background.primary,
        },
        style
      ]}
    >
      <Image
        source={typeof source === 'string' ? { uri: source } : source}
        style={[
          styles.image,
          {
            width: avatarSize,
            height: avatarSize,
            borderRadius: avatarSize / 2,
          }
        ]}
      />
      
      {status && (
        <View
          style={[
            styles.statusIndicator,
            {
              width: statusSize,
              height: statusSize,
              borderRadius: statusSize / 2,
              backgroundColor: getStatusColor(),
              borderColor: borderColor || colors.background.primary,
            }
          ]}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    overflow: 'hidden',
    borderWidth: 2,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  statusIndicator: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    borderWidth: 2,
  },
});