import React from 'react';
import { StyleSheet, ViewStyle } from 'react-native';
import { View, Text } from '@/components/themed';
import { Geofence } from '@/types';
import Colors from '@/constants/Colors';
import useThemeStore from '@/store/themeStore';
import { MapPin } from 'lucide-react-native';

type GeofenceCircleProps = {
  geofence: Geofence;
  isActive?: boolean;
  style?: ViewStyle;
};

export function GeofenceCircle({ 
  geofence, 
  isActive = false,
  style,
}: GeofenceCircleProps) {
  const theme = useThemeStore(state => state.currentTheme());
  const colors = Colors[theme];
  
  const activeColor = isActive ? 
    colors.primary[300] : 
    colors.gray[300];
  
  return (
    <View style={[styles.container, style]}>
      {/* Outer circle representing the geofence radius */}
      <View 
        style={[
          styles.circle, 
          { 
            borderColor: activeColor,
            borderWidth: 1.5,
            backgroundColor: activeColor + '33',  // 20% opacity
          }
        ]}
      />
      
      {/* Center pin */}
      <View 
        style={[
          styles.pin, 
          { 
            backgroundColor: colors.background.primary,
            borderColor: activeColor,
          }
        ]}
      >
        <MapPin 
          size={16} 
          color={isActive ? colors.primary[500] : colors.gray[500]} 
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  circle: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    borderRadius: 1000, // Just make it a big number to ensure circle
  },
  pin: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
  },
});