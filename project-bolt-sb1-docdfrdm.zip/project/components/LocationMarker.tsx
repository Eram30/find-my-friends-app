import React from 'react';
import { StyleSheet, Image, ViewStyle } from 'react-native';
import { View, Text } from '@/components/themed';
import { Friend } from '@/types';
import Colors from '@/constants/Colors';
import useThemeStore from '@/store/themeStore';
import spacing from '@/constants/Spacing';
import Animated, { 
  useSharedValue, 
  useAnimatedStyle, 
  withRepeat, 
  withTiming,
  withSequence,
  withDelay,
  Easing,
} from 'react-native-reanimated';

type LocationMarkerProps = {
  friend: Friend;
  isSelected?: boolean;
  style?: ViewStyle;
};

export function LocationMarker({ 
  friend, 
  isSelected = false,
  style,
}: LocationMarkerProps) {
  const theme = useThemeStore(state => state.currentTheme());
  const colors = Colors[theme];
  
  // Animated values
  const scale = useSharedValue(1);
  const pulse = useSharedValue(0);
  
  // Create pulse effect
  React.useEffect(() => {
    if (isSelected) {
      // Initial delay then pulsate
      pulse.value = withRepeat(
        withSequence(
          withTiming(1, { duration: 500, easing: Easing.out(Easing.ease) }),
          withTiming(0, { duration: 500, easing: Easing.in(Easing.ease) })
        ),
        -1, // Infinite repeat
        false // Don't reverse
      );
      
      // Slight bounce effect
      scale.value = withSequence(
        withTiming(1.2, { duration: 200 }),
        withTiming(1, { duration: 150 })
      );
    } else {
      scale.value = withTiming(1);
      pulse.value = 0;
    }
  }, [isSelected]);
  
  // Animated styles
  const markerStyle = useAnimatedStyle(() => {
    return {
      transform: [{ scale: scale.value }],
    };
  });
  
  const pulseStyle = useAnimatedStyle(() => {
    return {
      opacity: 0.4 - (0.4 * pulse.value),
      transform: [
        { scale: 1 + pulse.value },
      ],
    };
  });
  
  return (
    <View style={[styles.container, style]}>
      {/* Pulse effect circle */}
      {isSelected && (
        <Animated.View
          style={[
            styles.pulse,
            { backgroundColor: colors.primary[500] },
            pulseStyle,
          ]}
        />
      )}
      
      {/* Main marker */}
      <Animated.View style={[styles.markerContainer, markerStyle]}>
        <View 
          style={[
            styles.marker, 
            { 
              borderColor: colors.background.primary,
              backgroundColor: isSelected ? colors.primary[500] : colors.secondary[500]
            }
          ]}
        >
          <Image
            source={{ uri: friend.avatar }}
            style={styles.avatar}
          />
        </View>
        
        {/* Shadow triangle */}
        <View 
          style={[
            styles.triangle,
            { backgroundColor: isSelected ? colors.primary[500] : colors.secondary[500] }
          ]}
        />
      </Animated.View>
      
      {/* Name label (only shown when selected) */}
      {isSelected && (
        <View 
          style={[
            styles.label,
            { backgroundColor: colors.background.primary }
          ]}
        >
          <Text variant="caption" numberOfLines={1}>{friend.name}</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
  },
  pulse: {
    position: 'absolute',
    width: 50,
    height: 50,
    borderRadius: 25,
    zIndex: 1,
  },
  markerContainer: {
    alignItems: 'center',
  },
  marker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 2,
    overflow: 'hidden',
    zIndex: 2,
  },
  avatar: {
    width: '100%',
    height: '100%',
  },
  triangle: {
    width: 16,
    height: 16,
    backgroundColor: 'red',
    transform: [{ rotate: '45deg' }],
    marginTop: -8,
    zIndex: 1,
  },
  label: {
    paddingHorizontal: spacing['2'],
    paddingVertical: spacing['1'],
    borderRadius: spacing['1'],
    marginTop: spacing['1'],
    maxWidth: 120,
  },
});